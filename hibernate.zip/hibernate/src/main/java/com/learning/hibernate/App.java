package com.learning.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class App {
	public static void main(String[] args) {
//    	StoreData();
//		fetchData();
		embeddableAnnotation(); 
	}

	private static void embeddableAnnotation() {
	/* Embeddable Annotation is used to store object of class to another class and add
		extra column in the database
		*/
		StudentAddressSchema address =new StudentAddressSchema();
		address.setHouseNo(100);
		address.setCity("Bhopal");
		address.setState("Madhya Pradesh");
		
	    Student_Schema student =new Student_Schema();
	    student.setId(99);
	    student.setName("Sanjay");
	    student.setAddress(address);
	    
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Student_Schema.class);
		
		SessionFactory factory = configuration.buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		session.save(student);
		
		tx.commit();
		
	}

	private static void fetchData() {
		// TODO Auto-generated method stub
		EmployeeInformation emp = null;
		Configuration configuration = new Configuration().configure().addAnnotatedClass(EmployeeInformation.class);

		SessionFactory factory = configuration.buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		emp=session.get(EmployeeInformation.class, 101);
		
		tx.commit();
		
		System.out.println(emp);
	}

	private static void StoreData() {
		EmployeeInformation employee = new EmployeeInformation();
		employee.setId(101);
		employee.setName("Sanjay");
		employee.setDesignation("Software Engineer");
		employee.setSalary(3.30f);
		Configuration con = new Configuration().configure().addAnnotatedClass(EmployeeInformation.class);

		SessionFactory sf = con.buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();

		session.save(employee);

		tx.commit();

		System.out.println("Your data save successfully!");

	}
}
