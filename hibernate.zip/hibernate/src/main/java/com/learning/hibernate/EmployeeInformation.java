package com.learning.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="EmpInfo")   //Entity name and table name are two different things
public class EmployeeInformation {
	@Id
	private int id;
	@Column(name="Employee_Name")
	private String name;
	private String designation;
	@Transient    //Transient is used to bypass the column
	private float salary;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeInformation [id=" + id + ", name=" + name + ", designation=" + designation + "]";
	}

}
